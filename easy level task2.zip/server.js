const express = require('express');
const app = express();

// Add this route to handle GET requests to '/'
const path = require('path');

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'serverapp.html')); // Ensure 'index.html' exists in your project folder
});


// Start the server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});


