const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// This tells Express to use EJS and where to find views
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Allow use of static files like CSS
app.use(express.static(path.join(__dirname, 'public')));

// Help process form data
app.use(express.urlencoded({ extended: true }));

// Main page route
app.get('/', (req, res) => {
    res.render('index');
});

// Form submission route
app.post('/submit', (req, res) => {
    const { name, email, age } = req.body;
    res.render('result', { name, email, age });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});